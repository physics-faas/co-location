import logging
from kubernetes import client, config
import yaml

class CollocationFunctions:

    def __init__(self, cfg, inClusterExecution:bool=True):
        if inClusterExecution:
            config.load_incluster_config()
        else:
            config.load_kube_config()
        self.v1=client.CoreV1Api()
        self.cfg=cfg

    def getActionName(self, podYml: yaml) -> str:
        return (podYml['metadata']['labels']['name']).split('-')[5]
    
    def filterCandidateNodesExtraResources(self, nodes:dict, extraResources:dict) -> dict:
        candidateNodes={}
        if extraResources is not None:
            for node in nodes:
                numExtraResources=0
                for resource in extraResources:
                    if resource in nodes[node]:
                        numExtraResources+=1
                if  len(extraResources) == numExtraResources:       
                    candidateNodes[node]=nodes[node]
        if len(candidateNodes)==0:
            return nodes
        return candidateNodes
    
    def filterNodesWithEnoughResources(self, podLimitsAndRequests:dict, nodes:dict, nodesStatus:dict) -> dict:
        candidateNodes={}
        numRequestsSatisfied = 0
        if podLimitsAndRequests is not None:
            for node in nodes:
                logging.info(nodes[node])
                logging.info(nodesStatus[node])
                logging.info(podLimitsAndRequests['requests'])
                if nodes[node]['CPU']-nodesStatus[node]['CPUm']>=podLimitsAndRequests['requests']['cpu']*1000:
                    numRequestsSatisfied+=1
                if nodes[node]['Mem']-nodesStatus[node]['MemoryMB']>=podLimitsAndRequests['requests']['memory']:
                    numRequestsSatisfied+=1
                if numRequestsSatisfied==len(podLimitsAndRequests['requests']):
                    candidateNodes[node]=nodes[node]
                    numRequestsSatisfied = 0

        if len(candidateNodes)==0:
            return None
        return candidateNodes
    
    def generateNodeAffinityRules(self, nodes: dict) -> dict:
        rules={'nodeSelectorTerms': [{'matchExpressions': [{'key': 'openwhisk-role', 'operator': 'In', 'values': ['invoker']}]}]}
        nodeAff=[]
        if nodes is not None:
            for node in nodes:
                if 'openwhisk-role' in nodes[node]:
                    nodeAff.append(node)
        if len(nodeAff)>0:
            rules['nodeSelectorTerms'][0]['matchExpressions'].append({'key':'kubernetes.io/hostname', 'operator': 'In', 'values':nodeAff })
        return rules
    
    def getFunctionsRunningInCandidateNodes(self, nodes: dict) -> dict:
        pods=self.v1.list_namespaced_pod(namespace=self.cfg['OW']['namespace'], label_selector='release=owdev')
        actionsPerNode={}
        for pod in pods.items:
            if 'invoker' in pod.metadata.labels and 'openwhisk/action' in pod.metadata.labels:
                print(pod.metadata.labels)
                print(pod.spec.node_name)
                print(nodes)
                if pod.spec.node_name in nodes.keys():
                    if pod.spec.node_name not in actionsPerNode:
                        actionsPerNode[pod.spec.node_name]=[]
                    if pod.metadata.labels['openwhisk/action'] not in actionsPerNode[pod.spec.node_name]:
                        actionsPerNode[pod.spec.node_name].append(pod.metadata.labels['openwhisk/action'])
        logging.info('Functions running in candidate nodes: '+str(actionsPerNode))
        return actionsPerNode
    
    def getPodResourcesUsage(self, podLimitsAndRequests: dict, functionMetrics:dict) -> dict:
        logging.info(functionMetrics)
        cpu=functionMetrics['numVCores']
        if functionMetrics['numVCores']<podLimitsAndRequests['requests']['cpu']:
            cpu=podLimitsAndRequests['requests']['cpu']
        mem = podLimitsAndRequests['requests']['memory']
        if functionMetrics['mem(MiB)']>podLimitsAndRequests['requests']['memory']:
            if 128<functionMetrics['mem(MiB)']<512:
                mem = 512
            elif 512<functionMetrics['mem(MiB)']<1024:
                mem = 1024
            elif 1024<functionMetrics['mem(MiB)']<1536:
                mem = 1536
            else:
                mem = 2048
        
        limitmemory=podLimitsAndRequests['limits']['memory']
        if podLimitsAndRequests['limits']['memory']<mem:
            limitmemory = mem
        return {'limits':{'memory': limitmemory}, 'requests': {'cpu': cpu, 'memory': mem}}
    
    def updatePodLimitsAndRequests(self, podYml:yaml, podResourcesUsage:dict):
        for type in podResourcesUsage:
            if 'memory' in podResourcesUsage[type]:
                podResourcesUsage[type]['memory']=str(podResourcesUsage[type]['memory'])+'Mi'
            if 'cpu' in podResourcesUsage[type]:
                podResourcesUsage[type]['cpu']=str(podResourcesUsage[type]['cpu']*1000)+'m'
        podYml['spec']['containers'][0]['resources'].update(podResourcesUsage)

    def getInterferencePods(self, functionName:str, functionsInterferences:list, functionsRunning:dict) -> list:
        interferences=[]
        for node in functionsRunning:
            for function in functionsRunning[node]:
                for functions in functionsInterferences:
                    if function in functions and functionsInterferences[functions][functionName]['increment%']>=float(self.cfg['INTERFERENCES']['increment_threshold']):
                        logging.info('Latency incremenent with the function '+functionName+' is co-located with function '+function+': '+str(functionsInterferences[functions][functionName]['increment%']))
                        interferences.append(function)
        return interferences
    
    def generatePodAntiAffinityRules(self, functionsInterferenceName:list) -> dict:
        rules={}
        if len(functionsInterferenceName)>0:
            rules=  {'requiredDuringSchedulingIgnoredDuringExecution':[{ 'labelSelector': {'matchExpressions': [{'key':'openwhisk/action', 'operator': 'In', 'values': functionsInterferenceName}]},'topologyKey': 'kubernetes.io/hostname'}]}
        return rules
    
    def filterNodesWithEnoughResourcesProfiling(self, profiling: dict, nodes: dict, nodesStatus: dict) -> dict:
        candidateNodes={}
        if profiling is not None:
            for node in nodes:
                for resource in profiling:
                    if 'cpu' in resource:
                        if self._checkResourceProfile(nodesStatus[node], 'CPU%', profiling[resource]):
                            candidateNodes[node]=nodes[node]
                    if 'memory' in resource:
                        if self._checkResourceProfile(nodesStatus[node], 'Memory%', profiling[resource]):
                            candidateNodes[node]=nodes[node]
        if len(candidateNodes)==0:
            return None
        return candidateNodes

    def _checkResourceProfile(self, node:dict, resource:str, resourceProfiling:str) -> bool:
        if (node[resource]<float(self.cfg['PROFILING']['lowResourceAvblPct']) and 'high' in resourceProfiling) or (node[resource]<float(self.cfg['PROFILING']['mediumResourceAvblPct']) and 'medium' in resourceProfiling) or (node[resource]<float(self.cfg['PROFILING']['highResourceAvblPct']) and 'low' in resourceProfiling):
            return True
        return False

    def addAffinityAndAntiAffinityRules(self, podYml:yaml, nodeAffinityRules:dict, podAntiAffinityRules:dict):
        if len(nodeAffinityRules)>0:
            podYml['spec']['affinity']['nodeAffinity']['requiredDuringSchedulingIgnoredDuringExecution'].update(nodeAffinityRules)     
            logging.info('Adding node affinity')
        if len(podAntiAffinityRules)>0:
            logging.info('Adding pod anti affinity')
            podYml['spec']['affinity']['podAntiAffinity'] = podAntiAffinityRules