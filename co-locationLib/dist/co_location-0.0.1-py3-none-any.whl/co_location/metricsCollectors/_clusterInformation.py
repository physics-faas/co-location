import os
import logging
import threading
import time
from kubernetes import client, config

#Load cluster config
#config.load_kube_config()
config.load_incluster_config()
v1=client.CoreV1Api()

clusterNodes={}

def startCollector(ClusterInformation):   
    logging.info('Start collecting metrics') 
    nodeDict={}
    nodes=v1.list_node(label_selector= 'node-role.kubernetes.io/worker')
    for node in nodes.items:
        specs={"CPU":node.status.allocatable['cpu'], "Mem":float(node.status.allocatable['memory'].split('K')[0])*0.000976562}
        if 'Network' in node.metadata.labels:
            specs["Network"]=node.metadata.labels['Network']
        if 'DiskType' in node.metadata.labels:
            specs["DiskType"]=node.metadata.labels['DiskType']
        if 'GPU'  in node.metadata.labels:
            specs["GPU"]=node.metadata.labels['GPU']

        if "m" in specs['CPU']: #mCores
            specs['CPU']=specs['CPU'].split('m')[0]
        else:  #Cores to mCores
            specs['CPU']=float(specs['CPU'])*1000            
        nodeDict[node.metadata.name]=specs
        if ('openwhisk-role', 'invoker') in node.metadata.labels.items():
            nodeDict[node.metadata.name].update({"openwhisk-role" : "invoker"}) 
           
    ClusterInformation._clusterNodes=nodeDict
    time.sleep(int(os.environ["FREQUENCY"]))

class ClusterInformation:
    def __init__(self):
        format = "%(asctime)s: %(message)s"
        logging.basicConfig(format=format, level=logging.INFO, datefmt="%H:%M:%S")
        self.thread = None
        self._clusterNodes = {}

    def start(self):
        if self.thread:
            raise Exception('Collection already running')
        
        try:
            self.thread = threading.Thread(target=startCollector, args=(self, ))
            self.thread.start()
        except:
            raise Exception('Error starting cluster information thread.')
    
    def getClusterNodes(self):
        return self._clusterNodes
    